package com.example.prietoweatherapp

data class WeatherResponse(
    val weather: List<Weather>
)

data class Weather(
    val main: String,
    val description: String,
    val icon: String
)
