package com.example.prietoweatherapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Fetch New York weather when app opens
        fetchWeather("New York")
    }

    private fun fetchWeather(city: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val client = OkHttpClient()
                val request = Request.Builder()
                    .url("https://api.openweathermap.org/data/2.5/weather?q=$city&appid=4b164800c0b85755f743ca8bb635c98c&units=metric")
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()

                if (response.isSuccessful && responseBody != null) {
                    val json = JSONObject(responseBody)
                    val weatherArray = json.getJSONArray("weather")
                    val weatherObject = weatherArray.getJSONObject(0)
                    val main = weatherObject.getString("main")
                    val description = weatherObject.getString("description") // ✅ fixed
                    val icon = weatherObject.getString("icon") // ✅ added
                    val cityName = json.getString("name")

                    val iconUrl = "https://openweathermap.org/img/wn/${icon}@2x.png"
                    println("ICON URL: $iconUrl") // debug log

                    // Update UI on main thread
                    withContext(Dispatchers.Main) {
                        findViewById<TextView>(R.id.tvCity).text = cityName
                        findViewById<TextView>(R.id.tvMain).text = main
                        findViewById<TextView>(R.id.tvDescription).text = description

                        // Load icon into ImageView
                        val imageView = findViewById<ImageView>(R.id.ivIcon)
                        Glide.with(this@MainActivity)
                            .load(iconUrl)
                            .placeholder(android.R.drawable.ic_menu_report_image)
                            .error(android.R.drawable.stat_notify_error)
                            .into(imageView)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
